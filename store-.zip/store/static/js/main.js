function hello(){

    alert("Hello,Javascript is linked Successfully")
}